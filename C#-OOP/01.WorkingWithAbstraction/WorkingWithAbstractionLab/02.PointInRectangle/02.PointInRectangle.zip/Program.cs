﻿using System;
using System.Linq;

namespace _02.PointInRectangle
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] rectangleData = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            Point topLeft = new Point(rectangleData[0], rectangleData[1]);
            Point bottomRight = new Point(rectangleData[2], rectangleData[3]);
            Rectangle rectang = new Rectangle(topLeft, bottomRight);

            int numberOfLines = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfLines; i++)
            {
                int[] pointCoordinates = Console.ReadLine()
                    .Split()
                    .Select(int.Parse)
                    .ToArray();

                Point newPoint = new Point(pointCoordinates[0], pointCoordinates[1]);
                if (rectang.Contains(newPoint))
                {
                    Console.WriteLine("True");
                }
                else
                {
                    Console.WriteLine("False");
                }
            }
        }
    }
}
